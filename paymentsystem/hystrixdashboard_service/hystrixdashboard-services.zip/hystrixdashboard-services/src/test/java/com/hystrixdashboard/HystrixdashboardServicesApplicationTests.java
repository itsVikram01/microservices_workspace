package com.hystrixdashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HystrixdashboardServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
